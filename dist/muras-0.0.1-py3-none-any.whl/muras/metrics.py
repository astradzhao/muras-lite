from typing import List, Optional, Dict, Any
from pydantic import BaseModel

class Sample(BaseModel):
    query: str
    contexts_text: List[str] = []
    contexts_image_paths: List[str] = []
    answer: str
    reference: Optional[str] = None

class ImageTextRelevance:
    """Stub metric: replace with CLIP/BLIP later."""
    name = "image_text_relevance"

    def score(self, sample: Sample) -> float:
        # TODO: implement with CLIP similarity between query↔images or caption↔images
        return 0.0

def evaluate(samples: List[Sample]) -> Dict[str, Any]:
    metric = ImageTextRelevance()
    scores = [metric.score(s) for s in samples]
    return {
        "metrics": {metric.name: sum(scores) / max(1, len(scores))},
        "n": len(scores),
    }
