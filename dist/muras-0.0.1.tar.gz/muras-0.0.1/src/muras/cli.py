import json
import sys
from .metrics import Sample, evaluate

def main():
    data = json.load(sys.stdin)  # list of dicts
    samples = [Sample(**d) for d in data]
    result = evaluate(samples)
    print(json.dumps(result, indent=2))
